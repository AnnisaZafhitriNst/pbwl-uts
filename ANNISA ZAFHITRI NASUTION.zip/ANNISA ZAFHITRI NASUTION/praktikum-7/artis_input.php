<h2>Tambah Data Artis</h2>

<form action="artis_proses.php" method="POST">
<table>
    <tr>
        <td>NAMA</td>
        <td><input type="text" name=i_nama></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" name="b_input" value="SIMPAN"></td>
    </tr>
</table>
</form>