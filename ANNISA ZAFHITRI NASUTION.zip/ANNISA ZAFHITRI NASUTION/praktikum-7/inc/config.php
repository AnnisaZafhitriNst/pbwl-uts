<?php

session_start();

define ('URL', 'http://localhost/praktikum-7/');

define ('ASSET', URL . 'layout/assets/');

require_once "vendor/autoload.php";